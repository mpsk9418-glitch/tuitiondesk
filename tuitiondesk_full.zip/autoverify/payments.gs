// TuitionDesk auto-verify (Google Apps Script). Runs free on Google, 24x7.
// 1) UTR match: parent sent a UTR and the FamPay email has the same UTR and the same fee.
// 2) Paisa match: no UTR needed. Each student pays fee + paisa/100 (e.g. 3500.07),
//    so the exact amount in the FamPay email identifies the student.
// Anything else is logged as "CHECK MANUALLY" and changes nothing.
//
// Script properties: SUPA_URL, SUPA_KEY, TEACHER_EMAIL, TEACHER_PASSWORD, DRY_RUN

function P_() { return PropertiesService.getScriptProperties(); }

function authToken_() {
  const r = UrlFetchApp.fetch(P_().getProperty('SUPA_URL') + '/auth/v1/token?grant_type=password', {
    method: 'post', contentType: 'application/json', muteHttpExceptions: true,
    headers: { apikey: P_().getProperty('SUPA_KEY') },
    payload: JSON.stringify({ email: P_().getProperty('TEACHER_EMAIL'), password: P_().getProperty('TEACHER_PASSWORD') }),
  });
  const j = JSON.parse(r.getContentText());
  return j.access_token || null;
}

function sb_(path, method, body, tok, prefer) {
  const headers = { apikey: P_().getProperty('SUPA_KEY'), Authorization: 'Bearer ' + tok };
  if (prefer) headers.Prefer = prefer;
  const o = { method: method, headers: headers, muteHttpExceptions: true, contentType: 'application/json' };
  if (body) o.payload = JSON.stringify(body);
  const r = UrlFetchApp.fetch(P_().getProperty('SUPA_URL') + '/rest/v1/' + path, o);
  return { code: r.getResponseCode(), text: r.getContentText() };
}

function json_(path, tok) {
  return JSON.parse(sb_(path, 'GET', null, tok).text || '[]');
}

// Exact amount in rupees (keeps paise), and the UTR, from a FamPay "received" email.
function parseFampay_(text) {
  const amt = (text.match(/received\s*₹\s*([\d,]+(?:\.\d+)?)/i) || [])[1];
  const utr = (text.match(/UTR\s*:?\s*([A-Za-z0-9]{6,})/i) || [])[1];
  return { amount: amt ? Number(amt.replace(/,/g, '')) : null, utr: utr || null };
}

function thisMonth_() { return new Date().toISOString().slice(0, 7); }

function markPaid_(studentId, month, amount, tok) {
  const today = new Date().toISOString().slice(0, 10);
  return sb_('fee_status?on_conflict=student_id,month', 'POST',
    [{ student_id: studentId, month: month, amount: amount, paid: true, claimed: false, paid_on: today }],
    tok, 'resolution=merge-duplicates,return=minimal');
}

function alreadyPaid_(studentId, month, tok) {
  const r = json_('fee_status?student_id=eq.' + studentId + '&month=eq.' + month + '&select=paid', tok);
  return r.length && r[0].paid === true;
}

// Decide what to do with one payment email.
function handlePayment_(p, tok) {
  if (!p.amount) return 'SKIP (no amount in email)';
  const dry = P_().getProperty('DRY_RUN') === 'true';
  const month = thisMonth_();

  // 1) UTR path: parent sent this UTR
  if (p.utr) {
    const claims = json_('claims?utr=eq.' + encodeURIComponent(p.utr) + '&select=*', tok);
    if (claims.length) {
      const c = claims[0];
      const st = json_('students?id=eq.' + c.student_id + '&select=id,name,fee,paisa', tok)[0];
      if (!st) return 'CHECK MANUALLY (student not found)';
      const want = Number(st.fee) + (Number(st.paisa) || 0) / 100;
      const exact = Math.abs(want - p.amount) < 0.005 || Math.abs(Number(st.fee) - p.amount) < 0.005;
      if (!exact) return 'CHECK MANUALLY (amount ' + p.amount + ' != fee ' + st.fee + ')';
      if (dry) return 'WOULD VERIFY ' + st.name + ' by UTR (dry run)';
      markPaid_(c.student_id, c.month || month, Number(st.fee), tok);
      sb_('claims?id=eq.' + c.id, 'DELETE', null, tok, 'return=minimal');
      return 'VERIFIED ' + st.name + ' by UTR';
    }
  }

  // 2) Paisa path: amount = fee + paisa/100 identifies the student
  const students = json_('students?select=id,name,fee,paisa', tok);
  const hits = students.filter(function (s) {
    const want = Number(s.fee) + (Number(s.paisa) || 0) / 100;
    return (Number(s.paisa) || 0) > 0 && Math.abs(want - p.amount) < 0.005;
  });
  if (hits.length === 1) {
    const st = hits[0];
    if (alreadyPaid_(st.id, month, tok)) return 'ALREADY PAID ' + st.name;
    if (dry) return 'WOULD VERIFY ' + st.name + ' by paisa (dry run)';
    markPaid_(st.id, month, Number(st.fee), tok);
    json_('claims?student_id=eq.' + st.id + '&select=id', tok); // no-op read
    sb_('claims?student_id=eq.' + st.id + '&month=eq.' + month, 'DELETE', null, tok, 'return=minimal');
    return 'VERIFIED ' + st.name + ' by paisa';
  }
  if (hits.length > 1) return 'CHECK MANUALLY (amount matches more than one student)';
  return 'CHECK MANUALLY (no student has this amount ' + p.amount + ')';
}

function doneLabel_() {
  return GmailApp.getUserLabelByName('tuitiondesk-done') || GmailApp.createLabel('tuitiondesk-done');
}

// Runs every 5 minutes (see installTrigger).
function checkPayments() {
  const tok = authToken_();
  if (!tok) { Logger.log('Teacher login failed. Check TEACHER_EMAIL / TEACHER_PASSWORD.'); return; }
  const threads = GmailApp.search('(famapp OR FamApp) subject:received -label:tuitiondesk-done newer_than:3d', 0, 50);
  checkScreenshots_(tok);
  threads.forEach(function (t) {
    t.getMessages().forEach(function (m) {
      const p = parseFampay_(m.getPlainBody() || m.getBody());
      Logger.log(m.getDate() + ' | ' + (p.amount || '-') + ' | UTR ' + (p.utr || '-') + ' | ' + handlePayment_(p, tok));
    });
    t.addLabel(doneLabel_());
  });
}

// Run ONCE from the editor to start the 5-minute schedule.
function installTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) { ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('checkPayments').timeBased().everyMinutes(5).create();
}

// ---------- Screenshot verification (OCR) ----------
// Reads parent's payment screenshot with Google Drive OCR (free), then checks
// that a real FamPay "received" email with the same UTR and amount exists.
// Needs the Drive API turned on: Apps Script > Services (+) > Drive API > Add.
function ocrText_(dataUrl) {
  const b64 = String(dataUrl).split(',')[1];
  const blob = Utilities.newBlob(Utilities.base64Decode(b64), 'image/jpeg', 'proof.jpg');
  const file = Drive.Files.insert({ title: 'proof-' + Date.now(), mimeType: MimeType.GOOGLE_DOCS }, blob, { ocr: true, ocrLanguage: 'en' });
  let text = '';
  try { text = DocumentApp.openById(file.id).getBody().getText(); }
  finally { Drive.Files.remove(file.id); }
  return text;
}

function checkScreenshots_(tok) {
  const claims = json_('claims?proof=not.is.null&select=*', tok);
  claims.forEach(function (c) {
    let text = '';
    try { text = ocrText_(c.proof); } catch (e) { Logger.log('OCR failed for claim ' + c.id + ': ' + e); return; }
    const utr = (text.match(/UTR\s*:?\s*([A-Za-z0-9]{6,})/i) || [])[1];
    const amt = (text.match(/₹\s*([\d,]+(?:\.\d+)?)/) || [])[1];
    if (!utr || !amt) { Logger.log('Screenshot ' + c.id + ': CHECK MANUALLY (could not read UTR or amount)'); return; }
    const amount = Number(amt.replace(/,/g, ''));
    // The screenshot must match a real FamPay "received" email with the same UTR
    const found = GmailApp.search('"' + utr + '" (famapp OR FamApp) subject:received', 0, 1);
    if (!found.length) { Logger.log('Screenshot ' + c.id + ' UTR ' + utr + ': CHECK MANUALLY (no matching FamPay email)'); return; }
    const body = found[0].getMessages()[0].getPlainBody();
    const real = parseFampay_(body);
    if (real.utr !== utr || Math.abs((real.amount || 0) - amount) > 0.005) {
      Logger.log('Screenshot ' + c.id + ': CHECK MANUALLY (screenshot and email do not match)'); return;
    }
    const st = json_('students?id=eq.' + c.student_id + '&select=id,name,fee', tok)[0];
    if (!st || Number(st.fee) > amount + 0.005) { Logger.log('Screenshot ' + c.id + ': CHECK MANUALLY (amount less than fee)'); return; }
    if (P_().getProperty('DRY_RUN') === 'true') { Logger.log('Screenshot ' + c.id + ': WOULD VERIFY ' + st.name + ' (dry run)'); return; }
    markPaid_(c.student_id, c.month || thisMonth_(), Number(st.fee), tok);
    sb_('claims?id=eq.' + c.id, 'DELETE', null, tok, 'return=minimal');
    Logger.log('Screenshot ' + c.id + ': VERIFIED ' + st.name);
  });
}
