TuitionDesk auto-verify (Google Apps Script)

1. Open script.google.com with the Gmail that receives FamPay emails.
2. New project. Delete the old code. Paste the whole payments.gs file. Save.
3. Services (+) > add "Drive API" (needed for screenshot reading).
4. Project Settings > Script Properties:
   SUPA_URL, SUPA_KEY, TEACHER_EMAIL, TEACHER_PASSWORD, DRY_RUN
5. Run installTrigger once (allow permissions).
6. Check Executions. Start with DRY_RUN = true for a week.
